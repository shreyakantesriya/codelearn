$("form").submit((e)=>{
    e.prevenDefautl();
    let bookId = $("input[name = 'BookId']").val();
    let bookName = $("input[name='bookName']").val();
    let author = $("input[name='author']").val();
    let type = $("input[name='type']").val();

    $("#table tbody").append(
    "<tr data-bookId='"+bookId+"' data-bookName='"+bookName+"' data-author='"+author+"'data-type='"+type+"'><td>"+bookId+"</td><td>"+bookName+"</td><td>"+author+"</td> <td>"+type+"</td></tr>");
    

});